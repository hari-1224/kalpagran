<!-- resources/views/emails/contact.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Form Submission</title>
</head>
<body>
    <p>{{  $name  }}</p>
<p>{{  $phone  }}</p>
<p>{{  $email  }}</p>
<p>{{  $message_data  }}</p>
</body>
</html>
