@extends('layouts.app')
<style>
    .sx-thum-bx img {
        border-radius: 10px;
        border: 5px solid #209dd8;
        margin-bottom: 35px;
    }

    .image-container {
        position: relative;
    }

    .image-overlay {
        position: absolute;
        top: 5px;
        left: 5px;
        display: flex;

        background: rgba(0, 0, 0, 0.5);
        color: #fff;
    }

    #image-container img {
        border: 8px solid #d1f1ff00;
        border-radius: 15px;
        max-width: 30%;
    }

    .horizontal-images {
        display: flex;
        list-style: none;
        padding: 0;
        margin: 0;
        opacity: 0;
        transition: opacity 1.3s, transform 1.3s;
        transform: translateY(100%);
    }

    .container .product {
        margin-top: -50px;
    }

    .show-all-button {
        display: flex;
        justify-content: center;
        align-items: center;
        flex-wrap: wrap; 
    }

    #product-buttons {
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .product-button {
        margin: 0 5px; 
    }

    #image-container img {
        /* max-width: 100%; */
        margin-bottom: 10px; 
    }

    @media only screen and (max-width: 768px) {
        .show-all-button,
        #product-buttons {
            flex-direction: column;
            align-items: center;
        }

        .product-button {
            margin: 5px 0;
            width: 100%;
        }

        #image-container img {
            max-width: 100%; 
        }
        .mb-4.text-center h3 {
            margin-top: -100px; 
        }
    }
</style>





@section('content')
<!-- CONTENT START -->
<div class="page-content">
    <!-- INNER PAGE BANNER -->
    <div class="sx-bnr-inr overlay-wraper bg-parallax bg-top-center" data-stellar-background-ratio="0.5">
        <div class="overlay-main bg-black opacity-07"></div>
        <div class="container">
            <div class="sx-bnr-inr-entry">
                <div class="banner-title-outer">
                    <div class="banner-title-name" style="visibility: hidden;">
                        <h2 class="m-tb0">Our Products</h2>
                        <p>Here at Kalpa Granites PVT Ltd., Tamil Nadu, India. We are leading Granite Exporters of Slabs
                            and Cut size slabs.</p>
                    </div>
                </div>
                <!-- BREADCRUMB ROW -->
                <div class="product">
                    <ul style="visibility:hidden">
                        <li><a href="javascript:void(0);">Home</a></li>
                        <!--<li>Our Products</li>-->
                    </ul>
                    {{-- <form method="GET" action="{{ route('products.search') }}"
                        class="form-inline my-2 my-lg-0 text-center"> --}}
                        {{-- @csrf --}}
                        <div class="container">
                            <div class="mb-4 text-center">
                                <h3><b>Natural Stones From Top Marbles And Granite Suppliers<b></h3>
                            </div>

                            
                            <div class=" justify-content-center align-items-center show-all-button">
                                
                                    <button class="btn btn-primary btn-sm mx-1 mb-2 product-button"
                                        data-image-name="show-all" type="button" id="show-all">Show All</button>
                                <div class="">
                                    <div id="product-buttons" class="mb-2 ">
                                        @foreach ($products as $product)
                                        <button class="btn btn-primary btn-sm mx-1 product-button"
                                            data-image-name="{{ $product->name }}">{{ $product->name }}</button>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                            
                            
                            
                            
                        </div>
                        {{--
                    </form> --}}
                </div>
            </div>
        </div>
    </div>
</div>


<!-- BREADCRUMB ROW END -->
</div>
</div>
</div>
<!-- INNER PAGE BANNER END -->

<!-- SECTION CONTENT START -->
<div class="search-results-container">

</div>
<div class="section-full p-tb80 inner-page-padding">
    <div class="container">
        <div id="image-container" class="text-center mt-4 mb-4 ">
            <!-- The image will be displayed here -->
        </div>



    </div>


</div>
<!-- SECTION CONTENT END  -->

</div>
<!-- CONTENT END -->
{{-- <style>
    #image-container img {
        border: 5px solid #209dd8;
        border-radius: 10px;
        max-width: 100%;
    }
</style> --}}
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    function loadImage(productName) {
  var imageContainer = $('#image-container');
  imageContainer.empty();

  var loadingAnimation = $('<div>Loading...</div>').css({
    'background-color': '#fff',
    'border': '1px solid #ccc',
    'padding': '10px',
    'text-align': 'center',
  });

  imageContainer.append(loadingAnimation);

  $.ajax({
    type: 'GET',
    url: '{{ route('get-product-image') }}',
    data: { name: productName },
    beforeSend: function() {
      loadingAnimation.show();
    },
    success: function(data) {
      imageContainer.empty();

      if (data.image_urls && data.image_urls.length > 0) {
        data.image_urls.forEach(function(imageUrl) {
          // Create an image element with the original size
        //   var imageItem = $('<img src="' + imageUrl + '" alt="Image">');

          var imageItem = $('<img src="' + imageUrl + '" alt="Image">');
        //   var productNameDiv = $(' <div class="image-overlay"><h4 class="sx-title m-t0">product->name</h4></div>');
        //     imageContainer.append(imageItem, productNameDiv);
          imageContainer.append(imageItem);
        });

        setTimeout(function() {
          imageContainer.find('img').css({
            'opacity': 1,
            'transform': 'translateY(0)',
          });
        }, 10);
      } else {
        imageContainer.html('No images found');
      }
      loadingAnimation.hide();
    },
    error: function(xhr) {
      $('#image-container').html('Error: Images not found');
      loadingAnimation.hide();
    }
  });
}
$(document).ready(function() {
  // Default productName
  var defaultProductName = 'show-all';

  // Call the function with the default productName
  loadImage(defaultProductName);

  $('.product-button').click(function(e) {
    e.preventDefault();
    var productName = $(this).data('image-name');

    // Call the function with the clicked productName
    loadImage(productName);
  });
});

</script>





@endsection